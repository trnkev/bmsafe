#ifndef TEMP_H
#define TEMP_H

int ADC_ConvertVol2Temp(int ADC_Volt);

#endif